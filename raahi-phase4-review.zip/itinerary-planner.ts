// src/lib/itinerary-planner.ts
/**
 * Core itinerary generation and simple route optimization for the Raahi planner.
 * This implementation is deterministic, uses straight‑line (haversine) distances,
 * respects must‑visit attractions, crowd tolerance and travel pace.
 */
import { PLACES, Place } from '@/lib/jaipur-data';
import { haversine } from '@/lib/distance';
import { predictCrowd, type CrowdPrediction } from '@/lib/crowd-service';
import { ItineraryRequest } from './itinerary-request';

/** Helper: list of dates (inclusive) between start and end (ISO strings) */
export function daysBetween(start: string, end: string): string[] {
  const dates: string[] = [];
  const cur = new Date(start);
  const last = new Date(end);
  while (cur <= last) {
    dates.push(cur.toISOString().split('T')[0]);
    cur.setDate(cur.getDate() + 1);
  }
  return dates;
}

/** Map vibe IDs to places that have matching tags */
function placesForVibes(vibes: string[]): Place[] {
  const set = new Set(vibes);
  return PLACES.filter((p) => p.tags.some((t) => set.has(t)));
}

/** Build a candidate list of attraction IDs, ensuring must‑visits are included */
function buildCandidateList(req: ItineraryRequest): string[] {
  const candidates = new Set<string>();
  // Add must‑visit attractions first
  req.mustVisit.forEach((id) => candidates.add(id));
  // Add places matching the selected vibes
  placesForVibes(req.interests).forEach((p) => candidates.add(p.id));
  // Ensure at least one candidate per day; if empty fallback to all places
  if (candidates.size === 0) {
    PLACES.forEach((p) => candidates.add(p.id));
  }
  return Array.from(candidates);
}

/** Simple heuristic to order stops for a single day based on distance */
function nearestNeighbourOrder(ids: string[], startId: string | null = null): string[] {
  const remaining = new Set(ids);
  const ordered: string[] = [];
  let current = startId;
  while (remaining.size) {
    let next: string | null = null;
    let bestDist = Infinity;
    remaining.forEach((id) => {
      const place = PLACES.find((p) => p.id === id)!;
      const from = current ? PLACES.find((p) => p.id === current)! : null;
      const dist = from ? haversine(from.lat, from.lng, place.lat, place.lng) : 0;
      if (dist < bestDist) {
        bestDist = dist;
        next = id;
      }
    });
    if (next) {
      ordered.push(next);
      remaining.delete(next);
      current = next;
    } else {
      break;
    }
  }
  return ordered;
}

/** Generate a multi‑day itinerary */
export function generateItinerary(req: ItineraryRequest): Record<string, string[]> {
  const days = daysBetween(req.startDate, req.endDate);
  const candidates = buildCandidateList(req);
  // Distribute candidates across days, preserving must‑visits first
  const perDay: Record<string, string[]> = {};
  // Simple round‑robin allocation
  let dayIndex = 0;
  candidates.forEach((id) => {
    const day = days[dayIndex % days.length];
    if (!perDay[day]) perDay[day] = [];
    perDay[day].push(id);
    dayIndex++;
  });
  // Optimize order within each day
  Object.keys(perDay).forEach((day) => {
    const ordered = nearestNeighbourOrder(perDay[day]);
    // If crowd tolerance is "avoid", we can drop extremely crowded places (>80)
    if (req.crowdTolerance === 'avoid') {
      const filtered = ordered.filter((id) => {
        const pred = predictCrowd(id) as CrowdPrediction;
        return pred.score <= 80; // arbitrary threshold
      });
      perDay[day] = filtered.length ? filtered : ordered; // fallback to original if all filtered out
    } else {
      perDay[day] = ordered;
    }
  });
  return perDay;
}

/** Optimize an existing day's stop list (re‑order) */
export function optimizeDayStops(dayStops: string[]): string[] {
  return nearestNeighbourOrder(dayStops);
}

